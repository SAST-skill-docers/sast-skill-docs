import React, { ReactElement } from 'react';

class App extends React.Component {
    render(): ReactElement {
        return <p> Hello, React! </p>;
    }
}

export default App;
